

Download Node JS https://nodejs.org/en/
Download Sublime Text https://www.sublimetext.com/



bisa jadi aplikasi jika punya iq tinggi
Hint:D/Node.js

Maaf jika tidak bisa kontak @myXLCare
untuk hilangin paket izi 
UNREG XL GO IZI
NO: NOMER YG MAU DI UNREG
KIRIM MELAUI EMAIL KE customerservice@xl.co.id

have fun By Rizky
contact 62895332310333
